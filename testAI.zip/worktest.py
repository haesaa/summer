# worktest.py
print('hello python')
